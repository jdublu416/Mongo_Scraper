module.exports = {
    Article: require("./Article"),
    Note: require("./Note")
  };